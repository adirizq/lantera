<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lantera</title>

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/main/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/main/app-dark.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/logo/favicon.ico')); ?>" type="image/x-icon">

    <?php echo $__env->yieldContent('head-assets'); ?>

    <?php echo $__env->yieldPushContent('head-scripts'); ?>
</head>

<body class="theme-light">
    <div id="app">
        <?php echo $__env->make('dashboard.layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="main">
            <header class="mb-3">
                <a href="#" class="burger-btn d-block d-xl-none">
                    <i class="bi bi-justify fs-3"></i>
                </a>
            </header>

            <div class="page-heading">
                <h3><?php echo e($page); ?></h3>
            </div>

            <?php echo $__env->yieldContent('content'); ?>

            <footer>
                <div class="footer clearfix mb-0 text-muted">
                    <div class="float-start">
                        <p>2022 &copy; Lantera</p>
                    </div>
                    <div class="float-end">
                        <p>Powered by <a href="https://sakubi.id">Sakubi Teknologi Indonesia</a></p>
                    </div>
                </div>
            </footer>
        </div>
    </div>

    <script src="<?php echo e(asset('assets/js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('body-scripts'); ?>
</body>

</html>
<?php /**PATH /home/adirizq/Projects/Web/lantera/resources/views/dashboard/layouts/main.blade.php ENDPATH**/ ?>