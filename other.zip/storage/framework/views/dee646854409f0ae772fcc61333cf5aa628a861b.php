

<?php $__env->startSection('head-assets'); ?>
    <link rel="stylesheet" href="assets/css/shared/iconly.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <section class="row">
            <div class="col-12">
                <div class="row">
                    <div class="col-6 col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-body px-4 py-4">
                                <div class="row">
                                    <div class="col-md-4 col-xxl-3 d-flex justify-content-start ">
                                        <div class="stats-icon blue mb-sm-2 mb-md-0 mb-xxl-0">
                                            <i class="iconly-boldHome"></i>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-xxl-9">
                                        <h6 class="text-muted font-semibold">Total Posyandu</h6>
                                        <h6 class="font-extrabold mb-0"><?php echo e($posyandu_count); ?></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-body px-4 py-4">
                                <div class="row">
                                    <div class="col-md-4 col-xxl-3 d-flex justify-content-start ">
                                        <div class="stats-icon green mb-sm-2 mb-md-0 mb-xxl-0">
                                            <i class="iconly-boldProfile"></i>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-xxl-9">
                                        <h6 class="text-muted font-semibold">Total Kader</h6>
                                        <h6 class="font-extrabold mb-0"><?php echo e($kader_count); ?></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-body px-4 py-4">
                                <div class="row">
                                    <div class="col-md-4 col-xxl-3 d-flex justify-content-start ">
                                        <div class="stats-icon red mb-sm-2 mb-md-0 mb-xxl-0">
                                            <i class="iconly-boldHeart"></i>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-xxl-9">
                                        <h6 class="text-muted font-semibold">Total Lansia</h6>
                                        <h6 class="font-extrabold mb-0"><?php echo e($lansia_count); ?></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-body px-4 py-4">
                                <div class="row">
                                    <div class="col-md-4 col-xxl-3 d-flex justify-content-start ">
                                        <div class="stats-icon purple mb-sm-2 mb-md-0 mb-xxl-0">
                                            <i class="iconly-boldDocument"></i>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-xxl-9">
                                        <h6 class="text-muted font-semibold">Total Pemeriksaan</h6>
                                        <h6 class="font-extrabold mb-0"><?php echo e($pemeriksaan_count); ?></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-xl-8">
                        <div class="card">
                            <div class="card-header">
                                <h4>Chart Data Pemeriksaan</h4>
                            </div>
                            <div class="card-body">
                                <div id="chart-data-pemeriksaan"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-xl-4">
                        <div class="card">
                            <div class="card-header">
                                <h4>Persetase Lansia per Posyandu</h4>
                            </div>
                            <div class="card-body">
                                <div id="chart-kader-puskesmas"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('body-scripts'); ?>
    <script src="<?php echo e(asset('assets/extensions/apexcharts/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/pages/dashboard.js')); ?>"></script>

    <script>
        var optionsDataPemeriksaan = {
            annotations: {
                position: "back",
            },
            dataLabels: {
                enabled: false,
            },
            chart: {
                type: "bar",
                height: 300,
            },
            fill: {
                opacity: 1,
            },
            plotOptions: {},
            series: [{
                name: "sales",
                data: [<?php echo e($pbm[0]); ?>, <?php echo e($pbm[1]); ?>, <?php echo e($pbm[2]); ?>, <?php echo e($pbm[3]); ?>, <?php echo e($pbm[4]); ?>, <?php echo e($pbm[5]); ?>, <?php echo e($pbm[6]); ?>, <?php echo e($pbm[7]); ?>, <?php echo e($pbm[8]); ?>, <?php echo e($pbm[9]); ?>, <?php echo e($pbm[10]); ?>, <?php echo e($pbm[11]); ?>],
            }, ],
            colors: "#6c9886",
            xaxis: {
                categories: [
                    "Jan",
                    "Feb",
                    "Mar",
                    "Apr",
                    "May",
                    "Jun",
                    "Jul",
                    "Aug",
                    "Sep",
                    "Oct",
                    "Nov",
                    "Dec",
                ],
            },
        }


        var chartDataPemeriksaan = new ApexCharts(
            document.querySelector("#chart-data-pemeriksaan"),
            optionsDataPemeriksaan
        )

        chartDataPemeriksaan.render()


        var optionsKaderPuskesmas = {
            series: [<?php echo e($kbp_d); ?>],
            labels: [<?php echo $kbp_p; ?>],
            chart: {
                type: 'donut'
            }
        }

        var chartKaderPuskesmas = new ApexCharts(
            document.querySelector("#chart-kader-puskesmas"),
            optionsKaderPuskesmas
        )

        chartKaderPuskesmas.render()
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adirizq/Projects/Web/lantera/resources/views/dashboard/puskesmas/dashboard.blade.php ENDPATH**/ ?>