


<?php $__env->startSection('content'); ?>
    <div class="auth-logo">
        <a href="/"><img src="<?php echo e(asset('assets/images/logo/logo.png')); ?>" alt="Logo" style="height: 4rem !important"></a>
    </div>
    <h1 class="auth-title">Sign Up</h1>
    <p class="auth-subtitle mb-5">Input your data to register to our website.</p>

    <form method="POST" action="<?php echo e(route('register')); ?>" id="register-form">
        <?php echo csrf_field(); ?>
        <h5 class="mb-3">Informasi Puskesmas</h5>
        <div class="form-group position-relative has-icon-left mb-4">
            <input required type="text" class="form-control form-control-lg <?php $__errorArgs = ['puskesmas_admin_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Nama Admin Puskesmas" name="puskesmas_admin_name" value=<?php echo e(old('puskesmas_admin_name')); ?>>
            <div class="form-control-icon">
                <i class="bi bi-person"></i>
            </div>
            <?php $__errorArgs = ['puskesmas_admin_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group position-relative has-icon-left mb-4">
            <input required type="text" class="form-control form-control-lg <?php $__errorArgs = ['puskesmas_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Nama Puskesmas" name="puskesmas_name" value=<?php echo e(old('puskesmas_name')); ?>>
            <div class="form-control-icon">
                <i class="bi bi-hospital"></i>
            </div>
            <?php $__errorArgs = ['puskesmas_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group position-relative has-icon-left mb-4">
            <input required type="text" class="form-control form-control-lg <?php $__errorArgs = ['puskesmas_head_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Nama Kepala Puskesmas" name="puskesmas_head_name" value=<?php echo e(old('puskesmas_head_name')); ?>>
            <div class="form-control-icon">
                <i class="bi bi-person"></i>
            </div>
            <?php $__errorArgs = ['puskesmas_head_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group position-relative has-icon-left mb-4">
            <input required type="text" class="form-control form-control-lg <?php $__errorArgs = ['puskesmas_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Kode Puskesmas" name="puskesmas_code" value=<?php echo e(old('puskesmas_code')); ?>>
            <div class="form-control-icon">
                <i class="bi bi-upc"></i>
            </div>
            <?php $__errorArgs = ['puskesmas_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="row">
            <div class="col-6">
                <div class="form-group position-relative has-icon-left mb-4">
                    <input required type="text" class="form-control form-control-lg <?php $__errorArgs = ['rt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="RT" name="rt" value=<?php echo e(old('rt')); ?>>
                    <div class="form-control-icon">
                        <i class="bi bi-pin-map"></i>
                    </div>
                    <?php $__errorArgs = ['rt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-6">
                <div class="form-group position-relative has-icon-left mb-4">
                    <input required type="text" class="form-control form-control-lg <?php $__errorArgs = ['rw'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="RW" name="rw" value=<?php echo e(old('rw')); ?>>
                    <div class="form-control-icon">
                        <i class="bi bi-pin-map"></i>
                    </div>
                    <?php $__errorArgs = ['rw'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
        <div class="form-group mb-4" id="provinsi_form" style="background-color: white !important">
            <label class="h6">Provinsi</label>
            <select required class="form-select" id="id_provinsi" name="id_provinsi">
                <option hidden value="">Pilih Provinsi</option>
                <?php $__currentLoopData = $provinsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['id_provinsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group mb-4" id="kota_form" style="background-color: white !important">
            <label class="h6">Kota / Kabupaten</label>
            <select required class="form-select" id="id_kota" name="id_kota">
            </select>
            <?php $__errorArgs = ['id_kota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group mb-4" id="kecamatan_form" style="background-color: white !important">
            <label class="h6">Kecamatan</label>
            <select required class="form-select" id="id_kecamatan" name="id_kecamatan">
            </select>
            <?php $__errorArgs = ['id_kecamatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group mb-4" id="kelurahan_form" style="background-color: white !important">
            <label class="h6">Kelurahan</label>
            <select required class="form-select" id="id_kelurahan" name="id_kelurahan">
            </select>
            <?php $__errorArgs = ['id_kelurahan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <h5 class="form-label mt-5 mb-3">Alamat Lengkap Puskesmas</h5>
            <textarea name="address" value=<?php echo e(old('address')); ?> id="address" rows="3" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></textarea>
            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <h5 class="mt-5 mb-3">Informasi Akun</h5>
        <div class="form-group position-relative has-icon-left mb-4">
            <input required type="text" class="form-control form-control-lg <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Username" name="username" value=<?php echo e(old('')); ?>>
            <div class="form-control-icon">
                <i class="bi bi-person"></i>
            </div>
            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group position-relative has-icon-left mb-4">
            <input required type="password" class="form-control form-control-lg <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" name="password">
            <div class="form-control-icon">
                <i class="bi bi-shield-lock"></i>
            </div>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group position-relative has-icon-left mb-4">
            <input required type="password" class="form-control form-control-lg <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Confirm Password" name="password_confirmation">
            <div class="form-control-icon">
                <i class="bi bi-shield-lock"></i>
            </div>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" id="submit-btn" class="btn btn-primary btn-block btn-lg shadow mt-5">Submit</button>
    </form>
    <div class="text-center mt-5 text-lg fs-4">
        <p class='text-gray-600'>Already have an account? <a href="<?php echo e(route('login')); ?>" class="font-bold">Login</a>.</p>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('body-scripts'); ?>
    <script src="<?php echo e(asset('assets/extensions/jquery/jquery.min.js')); ?>"></script>

    <script>
        $(document).on('change', '#id_provinsi', function() {
            var provinsiID = $(this).val();
            console.log(provinsiID)
            if (provinsiID) {
                $.ajax({
                    url: '/getCities/' + provinsiID,
                    type: "GET",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>"
                    },
                    dataType: "json",
                    success: function(data) {
                        if (data) {
                            $('#id_kota').empty();
                            $('#id_kota').append('<option hidden value="">Pilih Kabupaten / Kota</option>');
                            $.each(data, function(key, item) {
                                $('#id_kota').append('<option value="' + item.id + '">' + item.name + '</option>');
                            });
                        } else {
                            $('#id_kota').empty();
                        }
                    }
                });
            } else {
                $('#id_kota').empty();
            }
        });

        $(document).on('change', '#id_kota', function() {
            var kabID = $(this).val();
            if (kabID) {
                $.ajax({
                    url: '/getDistricts/' + kabID,
                    type: "GET",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>"
                    },
                    dataType: "json",
                    success: function(data) {
                        if (data) {
                            $('#id_kecamatan').empty();
                            $('#id_kecamatan').append('<option hidden value="">Pilih Kecamatan</option>');
                            $.each(data, function(key, item) {
                                console.log(item.name)
                                $('#id_kecamatan').append('<option value="' + item.id + '">' + item.name + '</option>');
                            });
                        } else {
                            $('#id_kecamatan').empty();
                        }
                    }
                });
            } else {
                $('#id_kecamatan').empty();
            }
        });

        $(document).on('change', '#id_kecamatan', function() {
            var kecamatanID = $(this).val();
            if (kecamatanID) {
                $.ajax({
                    url: '/getVillages/' + kecamatanID,
                    type: "GET",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>"
                    },
                    dataType: "json",
                    success: function(data) {
                        if (data) {
                            $('#id_kelurahan').empty();
                            $('#id_kelurahan').append('<option hidden value="">Pilih Kelurahan</option>');
                            $.each(data, function(key, item) {
                                $('#id_kelurahan').append('<option value="' + item.id + '">' + item.name + '</option>');
                            });
                        } else {
                            $('#id_kelurahan').empty();
                        }
                    }
                });
            } else {
                $('#id_kelurahan').empty();
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('auth.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adirizq/Projects/Web/lantera/resources/views/auth/register.blade.php ENDPATH**/ ?>