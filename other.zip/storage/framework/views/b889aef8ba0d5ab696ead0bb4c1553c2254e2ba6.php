<div id="sidebar" class="active">
    <div class="sidebar-wrapper active">
        <div class="sidebar-header position-relative">
            <div class="d-flex justify-content-between align-items-center">
                <div class="logo">
                    <a href="index.html"><img src="assets/images/logo/logo.png" alt="Logo" srcset="" style="height: 3rem !important"></a>
                </div>
                <div class="sidebar-toggler  x">
                    <a href="#" class="sidebar-hide d-xl-none d-block"><i class="bi bi-x bi-middle"></i></a>
                </div>
            </div>
        </div>
        <div class="sidebar-menu">
            <ul class="menu">
                <?php if(auth()->user()->role == 0): ?>
                    <li class="sidebar-item">
                        <div class="w-100 bg-light-primary p-3" style="border-radius: 0.5rem">
                            <span class="badge bg-danger m-0">Admin</span>
                            <br>
                            <span class="badge bg-primary mt-2">Admin Lantera</span>
                        </div>
                    </li>
                <?php elseif(auth()->user()->role == 1): ?>
                    <li class="sidebar-item">
                        <div class="w-100 bg-light-primary p-3" style="border-radius: 0.5rem">
                            <span class="badge bg-success m-0">Puskesmas</span>
                            <br>
                            <span class="badge bg-primary mt-2"><?php echo e(auth()->user()->puskesmas->nama_puskesmas); ?></span>
                        </div>
                    </li>
                <?php endif; ?>

                <li class="sidebar-title">Menu</li>

                <li class="sidebar-item <?php echo e($page == 'Dashboard' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('dashboard')); ?>" class='sidebar-link'>
                        <i class="bi bi-grid-fill"></i>
                        <span>Dashboard</span>
                    </a>
                </li>

                <?php if(auth()->user()->role == 0): ?>
                    <li class="sidebar-item <?php echo e($page == 'Puskesmas' ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('usersPuskesmas')); ?>" class='sidebar-link'>
                            <i class="bi bi-hospital-fill"></i>
                            <span>Puskesmas</span>
                        </a>
                    </li>
                <?php elseif(auth()->user()->role == 1): ?>
                    <li class="sidebar-item <?php echo e($page == 'Posyandu' ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('posyandu.index')); ?>" class='sidebar-link'>
                            <i class="bi bi-hospital-fill"></i>
                            <span>Posyandu</span>
                        </a>
                    </li>
                    <li class="sidebar-item <?php echo e($page == 'Kader' ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('kader.index')); ?>" class='sidebar-link'>
                            <i class="bi bi-person-fill"></i>
                            <span>Kader</span>
                        </a>
                    </li>
                    <li class="sidebar-item <?php echo e($page == 'Lansia' ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('lansia.index')); ?>" class='sidebar-link'>
                            <i class="bi bi-person-fill"></i>
                            <span>Lansia</span>
                        </a>
                    </li>
                    <li class="sidebar-item <?php echo e($page == 'Data Pemeriksaan' ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('pemeriksaan.index')); ?>" class='sidebar-link'>
                            <i class="bi bi-file-earmark-medical-fill"></i>
                            <span>Data Pemeriksaan</span>
                        </a>
                    </li>
                <?php endif; ?>

                

                <li class="sidebar-item mt-5">
                    <a class='sidebar-link bg-danger' href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="bi bi-box-arrow-left text-white"></i>
                        <span class="text-white">Logout</span>
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH /home/adirizq/Projects/Web/lantera/resources/views/dashboard/layouts/partials/sidebar.blade.php ENDPATH**/ ?>