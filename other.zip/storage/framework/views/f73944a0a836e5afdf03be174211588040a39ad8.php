<div id="sidebar" class="active">
    <div class="sidebar-wrapper active">
        <div class="sidebar-header position-relative">
            <div class="d-flex justify-content-between align-items-center">
                <div class="logo">
                    <a href="index.html"><img src="assets/images/logo/logo.png" alt="Logo" srcset="" style="height: 3rem !important"></a>
                </div>
                <div class="sidebar-toggler  x">
                    <a href="#" class="sidebar-hide d-xl-none d-block"><i class="bi bi-x bi-middle"></i></a>
                </div>
            </div>
        </div>
        <div class="sidebar-menu">
            <ul class="menu">
                <?php if(auth()->user()->role == 0): ?>
                    <li class="sidebar-item">
                        <div class="w-100 bg-light-primary p-3" style="border-radius: 0.5rem">
                            <span class="badge bg-danger m-0">Admin</span>
                            <br>
                            <span class="badge bg-primary mt-2">Admin Lantera</span>
                        </div>
                    </li>
                <?php elseif(auth()->user()->role == 1): ?>
                    <li class="sidebar-item">
                        <div class="w-100 bg-light-primary p-3" style="border-radius: 0.5rem">
                            <span class="badge bg-success m-0">Puskesmas</span>
                            <br>
                            <span class="badge bg-primary mt-2"><?php echo e(auth()->user()->puskesmas->nama_puskesmas); ?></span>
                        </div>
                    </li>
                <?php endif; ?>

                <li class="sidebar-title">Menu</li>

                <li class="sidebar-item <?php echo e($page == 'Dashboard' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('dashboard')); ?>" class='sidebar-link'>
                        <i class="bi bi-grid-fill"></i>
                        <span>Dashboard</span>
                    </a>
                </li>

                <li class="sidebar-item has-sub <?php echo e(in_array($page, ['Puskesmas', 'Kader']) ? 'active' : ''); ?>">
                    <a href="#" class='sidebar-link'>
                        <i class="bi bi-person-fill"></i>
                        <span>Users</span>
                    </a>
                    <ul class="submenu ">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Admin')): ?>
                            <li class="submenu-item <?php echo e($page == 'Puskesmas' ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('usersPuskesmas')); ?>">Puskesmas</a>
                            </li>
                        <?php endif; ?>
                        <li class="submenu-item <?php echo e($page == 'Kader' ? 'active' : ''); ?>">
                            <a href="component-badge.html">Kader</a>
                        </li>
                    </ul>
                </li>

                <li class="sidebar-item mt-5">
                    <a class='sidebar-link bg-danger' href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="bi bi-box-arrow-left text-white"></i>
                        <span class="text-white">Logout</span>
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH D:\Projects\Web\lantera\resources\views/dashboard/layouts/partials/sidebar.blade.php ENDPATH**/ ?>