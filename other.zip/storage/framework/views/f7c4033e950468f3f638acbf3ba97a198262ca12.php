

<?php $__env->startSection('head-assets'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/extensions/datatables.net-bs5/css/dataTables.bootstrap5.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/pages/datatables.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/extensions/toastify-js/src/toastify.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/extensions/sweetalert2/sweetalert2.min.css')); ?>">
    

    <style>
        .choices__inner {
            background-color: white !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <section class="section">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h4 class="card-title">Data Posyandu Puskesmas <?php echo e(auth()->user()->puskesmas->nama_puskesmas); ?></h4>
                    <a href="" class="btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#addModal">Tambah Posyandu</a>
                </div>
                <div class="card-body">
                    <div class="card-body">
                        <table class="table" id="table1">
                            <thead>
                                <tr>
                                    <th>Nama Posyandu</th>
                                    <th>Alamat</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $posyandu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($p->nama); ?></td>
                                        <td><?php echo e($p->alamat); ?></td>
                                        <td>
                                            <button class="btn icon btn-info" data-bs-toggle="modal" data-bs-target="#detailModal" data-id="<?php echo e($p->id); ?>">
                                                <i class="bi bi-eye-fill"></i>
                                            </button>
                                            <a type="button" id="btn-delete" class="btn btn-danger" data-id="<?php echo e($p->id); ?>" onclick="deleteData(this.getAttribute('data-id'))">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <form action="<?php echo e(route('posyandu.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Tambah Posyandu Baru</h5>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <div class="form-group mb-4">
                            <label class="h6">Nama Posyandu</label>
                            <input required type="text" class="form-control form-control-lg <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Nama Posyandu" name="nama" value=<?php echo e(old('nama')); ?>>
                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group mb-4" id="provinsi_form" style="background-color: white !important">
                            <label class="h6">Provinsi</label>
                            <select required class="form-select" id="id_provinsi" name="id_provinsi">
                                <option hidden value="">Pilih Provinsi</option>
                                <?php $__currentLoopData = $provinsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['id_provinsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group mb-4" id="kota_form" style="background-color: white !important">
                            <label class="h6">Kota / Kabupaten</label>
                            <select required class="form-select" id="id_kota" name="id_kota">
                            </select>
                            <?php $__errorArgs = ['id_kota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group mb-4" id="kecamatan_form" style="background-color: white !important">
                            <label class="h6">Kecamatan</label>
                            <select required class="form-select" id="id_kecamatan" name="id_kecamatan">
                            </select>
                            <?php $__errorArgs = ['id_kecamatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group mb-4" id="kelurahan_form" style="background-color: white !important">
                            <label class="h6">Kelurahan</label>
                            <select required class="form-select" id="id_kelurahan" name="id_kelurahan">
                            </select>
                            <?php $__errorArgs = ['id_kelurahan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="row">
                            <div class="col-6">
                                <div class="form-group mb-4">
                                    <label class="h6">RT</label>
                                    <input required type="text" class="form-control form-control-lg <?php $__errorArgs = ['rt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="RT" name="rt" value=<?php echo e(old('rt')); ?>>
                                    <?php $__errorArgs = ['rt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group mb-4">
                                    <label class="h6">RW</label>
                                    <input required type="text" class="form-control form-control-lg <?php $__errorArgs = ['rw'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="RW" name="rw" value=<?php echo e(old('rw')); ?>>
                                    <?php $__errorArgs = ['rw'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="h6">Alamat Lengkap</label>
                            <textarea required name="alamat" value=<?php echo e(old('alamat')); ?> id="alamat" rows="3" class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Alamat Lengkap Posyandu"></textarea>
                            <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Tambah Posyandu</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="detailModal" tabindex="-1" role="dialog" aria-labelledby="modal-notification" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered " role="document">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Detail Posyandu</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <div class="form-group mb-3">
                        <small class="text-muted">Nama Posyandu</small> <br>
                        <h5 id="nama">...</h5>
                    </div>

                    <div class="form-group mb-3">
                        <small class="text-muted">Alamat Posyandu</small> <br>
                        <h5 id="alamat">...</h5>
                    </div>

                    <div class="form-group mb-3">
                        <small class="text-muted">RT / RW</small> <br>
                        <h5 id="rt_rw">...</h5>
                    </div>

                    <div class="form-group mb-3">
                        <small class="text-muted">Provinsi</small> <br>
                        <h5 id="provinsi">...</h5>
                    </div>

                    <div class="form-group mb-3">
                        <small class="text-muted">Kota</small> <br>
                        <h5 id="kota">...</h5>
                    </div>

                    <div class="form-group mb-3">
                        <small class="text-muted">Kecamatan</small> <br>
                        <h5 id="kecamatan">...</h5>
                    </div>

                    <div class="form-group mb-3">
                        <small class="text-muted">Kelurahan</small> <br>
                        <h5 id="kelurahan">...</h5>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('body-scripts'); ?>
    <script src="<?php echo e(asset('assets/extensions/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/extensions/datatables.net-bs5/js/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/extensions/toastify-js/src/toastify.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/extensions/sweetalert2/sweetalert2.min.js')); ?>"></script>
    

    <?php if(!$errors->isEmpty()): ?>
        <script>
            var myModal = new bootstrap.Modal(document.getElementById('addModal'), {
                keyboard: false
            })

            myModal.show()

            console.log('<?php echo e($errors); ?>')
        </script>
    <?php endif; ?>

    <script>
        let jquery_datatable = $("#table1").DataTable()
    </script>

    <?php if(session()->has('success')): ?>
        <script>
            Toastify({
                text: "<?php echo e(session('success')); ?>",
                duration: 3000,
            }).showToast()
        </script>
    <?php endif; ?>

    <script>
        function deleteData(id) {
            console.log(id)

            Swal.fire({
                title: 'Yakin Hapus Posyandu?',
                text: "Posyandu yang telah dihapus tidak dapat dikembalikan!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Ya, Hapus Posyandu'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '/posyandu/' + id,
                        type: 'DELETE',
                        data: {
                            _token: "<?php echo e(csrf_token()); ?>",
                            id: id
                        },
                        complete: function() {
                            location.reload();
                        }
                    })

                }
            })
        }

        let choices = document.querySelectorAll(".choices")
        let initChoice
        for (let i = 0; i < choices.length; i++) {
            if (choices[i].classList.contains("multiple-remove")) {
                initChoice = new Choices(choices[i], {
                    delimiter: ",",
                    editItems: true,
                    maxItemCount: -1,
                    removeItemButton: true,
                })
            } else {
                initChoice = new Choices(choices[i])
            }
        }

        $(document).on('change', '#id_provinsi', function() {
            var provinsiID = $(this).val();
            console.log(provinsiID)
            if (provinsiID) {
                $.ajax({
                    url: '/getCities/' + provinsiID,
                    type: "GET",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>"
                    },
                    dataType: "json",
                    success: function(data) {
                        if (data) {
                            $('#id_kota').empty();
                            $('#id_kota').append('<option hidden value="">Pilih Kabupaten / Kota</option>');
                            $.each(data, function(key, item) {
                                $('#id_kota').append('<option value="' + item.id + '">' + item.name + '</option>');
                            });
                        } else {
                            $('#id_kota').empty();
                        }
                    }
                });
            } else {
                $('#id_kota').empty();
            }
        });

        $(document).on('change', '#id_kota', function() {
            var kabID = $(this).val();
            if (kabID) {
                $.ajax({
                    url: '/getDistricts/' + kabID,
                    type: "GET",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>"
                    },
                    dataType: "json",
                    success: function(data) {
                        if (data) {
                            $('#id_kecamatan').empty();
                            $('#id_kecamatan').append('<option hidden value="">Pilih Kecamatan</option>');
                            $.each(data, function(key, item) {
                                console.log(item.name)
                                $('#id_kecamatan').append('<option value="' + item.id + '">' + item.name + '</option>');
                            });
                        } else {
                            $('#id_kecamatan').empty();
                        }
                    }
                });
            } else {
                $('#id_kecamatan').empty();
            }
        });

        $(document).on('change', '#id_kecamatan', function() {
            var kecamatanID = $(this).val();
            if (kecamatanID) {
                $.ajax({
                    url: '/getVillages/' + kecamatanID,
                    type: "GET",
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>"
                    },
                    dataType: "json",
                    success: function(data) {
                        if (data) {
                            $('#id_kelurahan').empty();
                            $('#id_kelurahan').append('<option hidden value="">Pilih Kelurahan</option>');
                            $.each(data, function(key, item) {
                                $('#id_kelurahan').append('<option value="' + item.id + '">' + item.name + '</option>');
                            });
                        } else {
                            $('#id_kelurahan').empty();
                        }
                    }
                });
            } else {
                $('#id_kelurahan').empty();
            }
        });
    </script>

    <script>
        $('#detailModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget) // Button that triggered the modal
            var modal = $(this)

            $.ajax({
                url: "<?php echo e(url('')); ?>" + '/posyandu/' + button.data('id'),
                method: 'GET',
                dataType: "json",
                success: function(response) {
                    var data = response;
                    modal.find('.modal-body #nama').html(data['nama'])
                    modal.find('.modal-body #alamat').html(data['alamat'])
                    modal.find('.modal-body #rt_rw').html(data['rt'] + ' / ' + data['rw'])
                    modal.find('.modal-body #provinsi').html(data['provinsi'])
                    modal.find('.modal-body #kota').html(data['kota'])
                    modal.find('.modal-body #kecamatan').html(data['kecamatan'])
                    modal.find('.modal-body #kelurahan').html(data['kelurahan'])
                },
                error: function(xhr, status, error) {
                    var err = eval("(" + xhr.responseText + ")");
                    alert(err.Message);
                }
            });
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adirizq/Projects/Web/lantera/resources/views/dashboard/puskesmas/posyandu.blade.php ENDPATH**/ ?>