

<?php $__env->startSection('head-assets'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/extensions/datatables.net-bs5/css/dataTables.bootstrap5.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/pages/datatables.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/extensions/toastify-js/src/toastify.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <section class="section">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Data Kader Puskesmas</h4>
                </div>
                <div class="card-body">
                    <div class="card-body">
                        <table class="table" id="table1">
                            <thead>
                                <tr>
                                    <th>Nama Kader</th>
                                    <th>Alamat</th>
                                    <th>Tanggal Lahir</th>
                                    <th>Status Validasi</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $kader; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($k->nama); ?></td>
                                        <td><?php echo e($k->alamat_domisili); ?></td>
                                        <td><?php echo e($k->tgl_lahir); ?></td>
                                        <td>
                                            <?php if(isset($k->verified_at)): ?>
                                                <span class="badge bg-success">Tervalidasi</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger">Tidak Valid</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if(isset($k->verified_at)): ?>
                                                <a href="<?php echo e(route('removeValidationKader', $k->id)); ?>" class="btn icon btn-danger">
                                                    <i class="bi bi-x"></i>
                                                </a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('validatingKader', $k->id)); ?>" class="btn icon btn-success">
                                                    <i class="bi bi-check"></i>
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('body-scripts'); ?>
    <script src="<?php echo e(asset('assets/extensions/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/extensions/datatables.net-bs5/js/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/extensions/toastify-js/src/toastify.js')); ?>"></script>

    <script>
        let jquery_datatable = $("#table1").DataTable()
    </script>

    <?php if(session()->has('success')): ?>
        <script>
            Toastify({
                text: "<?php echo e(session('success')); ?>",
                duration: 3000,
            }).showToast()
        </script>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/adirizq/Projects/Web/lantera/resources/views/dashboard/users/kader.blade.php ENDPATH**/ ?>